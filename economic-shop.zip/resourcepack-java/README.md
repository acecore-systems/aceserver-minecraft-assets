# sekisei-trade-system Java版リソースパック

数値入力画面 (ショップの個数選択と、露店・送金の入力画面) の矢印と数字を絵で表示する。

## 現在の内容

| 対象 | 方式 | ファイル |
|---|---|---|
| 上下の矢印、0〜9 の数字 | 紙の custom_model_data で見た目を差し替える | `assets/minecraft/models/item/paper.json` (1.20.1〜1.21.3)、`assets/minecraft/items/paper.json` (1.21.4 以降) → `assets/sekisei/models/item/ui/` |

サーバーが 1.20.1 なので、アイテムの見た目は item_model ではなく custom_model_data で選ぶ。
値は `tools/build_resourcepacks.py` の `ICONS` と、プラグインの `UI/UiIcon.java` で同じにする。

1.21.4 以降のクライアントには、ViaVersion が整数の custom_model_data を floats の先頭に入れて送る。
`items/paper.json` はその値を `index: 0` で見る。

## ビルドと配布

```powershell
powershell -ExecutionPolicy Bypass -File tools\generate_icons.ps1
python tools\build_resourcepacks.py
```

`resourcepack-build/sekisei-trade-system.zip` ができる。
HTTP で配布し、`server.properties` の `resource-pack` に URL、`resource-pack-sha1` にビルド時に表示される sha1 を書く。
パックを入れていないプレイヤーには、名前の付いた紙として見える。
